package MoveValidator;

import edu.uj.po.interfaces.Move;

public interface MoveValidator {

    public boolean validateMove(Move move);
}

