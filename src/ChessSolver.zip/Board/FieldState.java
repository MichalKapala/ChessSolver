package Board;

public interface FieldState {
}
