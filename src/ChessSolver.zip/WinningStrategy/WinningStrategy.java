package WinningStrategy;

import Board.Board;

public interface WinningStrategy {
    public boolean CheckForWin(Board board);
}
