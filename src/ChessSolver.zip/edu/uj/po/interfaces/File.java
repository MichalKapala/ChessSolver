package edu.uj.po.interfaces;

/**
 * Kolumna na szachownicy
 */
public enum File {
	a, b, c, d, e, f, g, h;
}
